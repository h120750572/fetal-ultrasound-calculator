# GitHub 部署指南

## 📋 將急診產科超音波分析工具上傳到您的GitHub帳號

### 方法一：使用GitHub網頁介面（推薦）

#### 步驟1：創建新的GitHub倉庫
1. 登入您的GitHub帳號 (h120750572)
2. 點擊右上角的 "+" 按鈕，選擇 "New repository"
3. 填寫倉庫資訊：
   - **Repository name**: `fetal-ultrasound-calculator`
   - **Description**: `急診產科超音波分析工具 - 支援BPD+AC和CRL計算`
   - **Visibility**: 選擇 Public 或 Private
   - **不要勾選** "Add a README file"（我們已經有了）
4. 點擊 "Create repository"

#### 步驟2：上傳程式碼
1. 在新創建的倉庫頁面，找到 "uploading an existing file" 連結
2. 將提供的程式碼檔案拖拽到上傳區域，或點擊 "choose your files"
3. 上傳以下檔案：
   - 所有 `src/` 目錄下的檔案
   - `package.json`
   - `README.md`
   - `.gitignore`
   - `index.html`
   - `vite.config.js`
   - 其他配置檔案
4. 在 "Commit changes" 區域填寫：
   - **Commit message**: `Initial commit: 急診產科超音波分析工具`
5. 點擊 "Commit changes"

### 方法二：使用Git命令列（進階用戶）

如果您熟悉Git命令，可以使用以下指令：

```bash
# 1. 在GitHub上創建新倉庫後，複製倉庫URL
# 2. 在本地程式碼目錄中執行：

git remote add origin https://github.com/h120750572/fetal-ultrasound-calculator.git
git branch -M main
git push -u origin main
```

### 方法三：使用GitHub Desktop（圖形介面）

1. 下載並安裝 GitHub Desktop
2. 登入您的GitHub帳號
3. 點擊 "File" > "Add Local Repository"
4. 選擇程式碼資料夾
5. 點擊 "Publish repository"
6. 填寫倉庫名稱和描述
7. 點擊 "Publish Repository"

## 📁 程式碼結構說明

```
fetal-ultrasound-calculator/
├── src/
│   ├── components/ui/     # UI組件庫
│   ├── App.jsx           # 主要應用程式
│   ├── App.css           # 樣式檔案
│   └── main.jsx          # 入口檔案
├── public/               # 靜態資源
├── package.json          # 專案依賴
├── README.md            # 專案說明
├── .gitignore           # Git忽略檔案
└── vite.config.js       # 建置配置
```

## 🚀 部署到GitHub Pages（可選）

如果您想要將網站部署到GitHub Pages：

1. 在倉庫設定中找到 "Pages" 選項
2. 選擇 "GitHub Actions" 作為來源
3. 創建 `.github/workflows/deploy.yml` 檔案：

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - uses: actions/setup-node@v2
      with:
        node-version: '18'
    - run: npm install
    - run: npm run build
    - uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

## 📞 需要協助？

如果在上傳過程中遇到任何問題，請隨時聯繫我們！

---

**注意**：請確保不要上傳 `node_modules/` 和 `dist/` 資料夾，這些會自動生成。
